/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import de.eppleton.jbox2d.rendering.CircleProvider;
import javafx.scene.Node;
import org.jbox2d.collision.shapes.CircleShape;
import org.jbox2d.dynamics.Body;

/**
 *
 * @author eppleton
 */
public class MetalBallProvider implements CircleProvider< MetalBall> {

    @Override
    public Node configureNode(MetalBall circle, Body body, CircleShape shape, double offset_x, double offset_Y, float scale) {//, Transform[] transform) {
        if (circle == null) {
            circle = new MetalBall( //transform
                    );
            circle.setRadius(shape.m_radius * scale);
        }
        double layoutX = circle.getLayoutX();
        double layoutY = circle.getLayoutY();
        double newX = (body.getPosition().x + offset_x) * scale;
        double newY = ((body.getPosition().y * -1) + offset_Y) * scale;
        circle.setLayoutX(newX);
        circle.setLayoutY(newY);
//        circle.setBlur(distance(newX, newY, layoutX, layoutY), angle(newX, newY, layoutX, layoutY));
        return circle;
    }

    @Override
    public boolean providesNodeFor(Body body, CircleShape shape) {
        return shape instanceof CircleShape && (body.getUserData() != null && "ball".
                equals(body.getUserData()));
    }

    public double distance(double x1, double y1, double x2, double y2) {
        return Math.sqrt((((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1))));
    }

    public double angle(double x1, double y1, double x2, double y2) {

        return Math.atan2((y2 - y1), (x2 - x1)) * 180 / Math.PI;
    }
}
