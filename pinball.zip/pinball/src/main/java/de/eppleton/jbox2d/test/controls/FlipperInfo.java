/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import org.jbox2d.common.Vec2;

/**
 *
 * @author eppleton
 */
public class FlipperInfo {
    
    float length;
    float height;
    boolean left;
    float pivotX =0;
    float pivotY =0;
    Vec2 jointPosition;

    public Vec2 getJointPosition() {
        return jointPosition;
    }

    public void setJointPosition(Vec2 jointPosition) {
        this.jointPosition = jointPosition;
    }
    
    public float getPivotX() {
        return pivotX;
    }

    public void setPivotX(float pivotX) {
        this.pivotX = pivotX;
    }

    public float getPivotY() {
        return pivotY;
    }

    public void setPivotY(float pivotY) {
        this.pivotY = pivotY;
    }
    
    
    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public boolean isLeft() {
        return left;
    }

    public void setLeft(boolean left) {
        this.left = left;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }
    
    
    
    
    
}
