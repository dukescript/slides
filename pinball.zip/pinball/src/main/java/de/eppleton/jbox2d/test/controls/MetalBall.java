/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import javafx.scene.CacheHint;
import javafx.scene.Parent;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.DropShadowBuilder;
import javafx.scene.effect.MotionBlur;
import javafx.scene.shape.Circle;

/**
 *
 * @author eppleton
 */
public class MetalBall extends Parent {

    MotionBlur mb = new MotionBlur(0, 0);
    Circle circle1;
    Circle circle2;
    DropShadow dropShadow = DropShadowBuilder.create().height(30).offsetX(3).
            offsetY(3).
            radius(10).width(15).
            build();
    double angle, radius;

    public MetalBall() {

        circle1 = javafx.scene.shape.CircleBuilder.create().radius(37).effect(dropShadow).
                build();
        circle1.getStyleClass().add("pinball-volume");
        circle2 = javafx.scene.shape.CircleBuilder.create().build();
        circle2.getStyleClass().add("pinball-halo");
        getChildren().add(circle1);
        getChildren().add(circle2);
        setEffect(mb);
    }

    void setRadius(float m_radius) {
        circle1.setRadius(m_radius);
        circle2.setRadius(m_radius);
    }

    void setBlur(double radius, double angle) {
        if (radius < 20) {
            setEffect(null);
            return;
        } else {
            setEffect(mb);
            if (this.radius != radius) {
                mb.setRadius(radius);
                this.radius = radius;
            }
            if (this.angle != angle) {
                mb.setAngle(angle);
                this.angle = angle;
            }
        }
    }
}
