/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.decoration;

import javafx.scene.Parent;
import javafx.scene.effect.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;

/**
 *
 * @author eppleton
 */
public class PinballMachineCover extends Parent {
    
    double width;
    double height;
    private Rectangle boxFrame;
    private Polygon bottomInfo;
    private Shape plungerCover;
    private Path topCover;
    private DropShadow dropShadow = DropShadowBuilder.create().offsetX(8).
            offsetY(8).
            radius(25).
            build();
    private InnerShadow innerShadow = InnerShadowBuilder.create().choke(0.006993006993006994).
            build();
    private static double frameWidth = 10d, plungerBoxHeight= 35d;
    private static double plungerBoxInsets = 7d, plungerBoxWidth = 40d;
    private static double infoWidth = 400d;
    public PinballMachineCover(double width, double height) {
        this.width = width;
        this.height = height;
        plungerBoxWidth = width - (2* frameWidth)-infoWidth;
        
        Light.Distant distantLight = new Light.Distant();
        
        distantLight.setAzimuth(
                225.0);
        boxFrame = RectangleBuilder.create().fill(Color.TRANSPARENT).
                stroke(Color.LIGHTGRAY).effect(LightingBuilder.create().
                specularConstant(2.0).
                specularExponent(17.142857142857146).
                contentInput(innerShadow).light(distantLight).bumpInput(innerShadow).
                build()).strokeType(StrokeType.INSIDE).
                strokeWidth(frameWidth).height(height).width(width).
                build();
        bottomInfo = PolygonBuilder.create().fill(Color.TRANSPARENT).
                fill(Color.WHITESMOKE).points(frameWidth, height -frameWidth, frameWidth, 660d,
                150d, 730d, 260d, 730d,
                frameWidth+ infoWidth, 660d,frameWidth+ infoWidth, height - frameWidth).
                build();
        MoveTo start = new MoveTo(frameWidth, frameWidth);
        LineTo lineTo = new LineTo(width - frameWidth,frameWidth);
        LineTo lineTo1 = new LineTo(width - frameWidth,frameWidth +100);
        CubicCurveTo curveTo = new CubicCurveTo(width -25, -20, -15, -20,frameWidth, frameWidth + 120);
        topCover = PathBuilder.create().elements( start, lineTo, lineTo1, curveTo ).
                fill(Color.WHITESMOKE).build();
        Rectangle plungerBox = RectangleBuilder.create().x(0).y(0).height(plungerBoxHeight).width(plungerBoxWidth).build();
        Rectangle cutout = RectangleBuilder.create().x(plungerBoxInsets).y(plungerBoxInsets).height(plungerBoxHeight - (2*plungerBoxInsets)).width(plungerBoxWidth- (2*plungerBoxInsets)).arcHeight(4).arcWidth(4).build();
        plungerCover = Shape.subtract(plungerBox, cutout);
        plungerCover.setLayoutX(frameWidth+ infoWidth);
        plungerCover.setLayoutY(height-plungerBoxHeight);
        plungerCover.setFill(Color.DARKBLUE);
        Shape shadowShape = Shape.union(Shape.union(Shape.union(boxFrame, bottomInfo),plungerCover),topCover);
        shadowShape.setEffect(dropShadow);
        setEffect(dropShadow);
       /* Duke duke = Duke.getInstance();
        duke.setLayoutX(220);
        duke.setLayoutY(-100);
        duke.setScaleX(.48);
        duke.setScaleY(.4);
        getChildren().addAll(//shadowShape,
                bottomInfo, plungerCover
                ,boxFrame, topCover,duke );*/
    }
    

}
