/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import de.eppleton.jbox2d.rendering.ChainProvider;
import javafx.scene.Node;
import org.jbox2d.collision.shapes.ChainShape;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.dynamics.Body;

/**
 *
 * @author eppleton
 */
public class RolloverProvider implements ChainProvider<Rollover> {

    @Override
    public Node configureNode(Rollover n, Body body, ChainShape shape, double offset_x, double offset_Y, float scale) {
        if (n == null) {
            n = new Rollover((RolloverInfo) body.getUserData(),scale, body, offset_x, offset_Y, shape);
        }
       
        return n;
    }

    @Override
    public boolean providesNodeFor(Body body, ChainShape shape) {
        if (
            body.getUserData() !=null && body.getUserData() instanceof RolloverInfo) {
            return true;
        }
        return false;
    }
}
