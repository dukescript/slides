/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;

/**
 *
 * @author eppleton
 */
public class DukeController implements DukeNoseLighter, Initializable{
   @FXML SVGPath nose;
   Color pale = Color.color( .4,0, 0); 
   
   public void lightUp(boolean light){
       nose.setFill(light?Color.RED: pale);
   }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }
}
