/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import de.eppleton.jbox2d.rendering.PolygonProvider;
import javafx.scene.Node;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.dynamics.Body;

/**
 *
 * @author eppleton
 */
public class FlipperProvider implements PolygonProvider<Flipper> {

    @Override
    public Node configureNode(Flipper n, Body body, PolygonShape shape, double offset_x, double offset_Y, float scale) {
        if (n == null) {
            FlipperInfo info = (FlipperInfo) body.getUserData();
            n = new Flipper(info, scale);
            n.setLayoutX((body.getPosition().x + offset_x) * scale);
            n.setLayoutY(((info.getJointPosition().y * -1) + offset_Y) * scale);
        }
        n.rotate(body.getAngle());

        return n;
    }

    @Override
    public boolean providesNodeFor(Body body, PolygonShape shape) {
        return (body.getUserData() instanceof FlipperInfo);
        //|| "rightFlipper".equals(body.getUserData())   
    }
    /*
    
     @Override
     public Polygon configureNode(Polygon polygon, Body body, PolygonShape shape, double offset_x, double offset_Y, float scale) {//, Transform[] transform) {
     if (polygon == null) {
     FlipperInfo userData = (FlipperInfo) body.getUserData();
     DropShadow dropShadow = DropShadowBuilder.create().height(41).offsetX(userData.left ? 10 : -10).
     offsetY(userData.left ? 10 : -10).
     radius(20).width(41).
     build();
     polygon = javafx.scene.shape.PolygonBuilder.create() //.transforms(transform)
     .fill(Color.RED).build();
     for (int i = 0; i < shape.getVertexCount(); i++) {
     Vec2 vec2 = shape.getVertex(i);
     Vec2 transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
     polygon.getPoints().add(((double) transformed.x + offset_x) * scale);
     polygon.getPoints().add((((double) transformed.y * -1) + offset_Y) * scale);
     }

     } else {
     for (int i = 0; i < shape.getVertexCount(); i++) {
     Vec2 vec2 = shape.getVertex(i);
     Vec2 transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);

     polygon.getPoints().set(i * 2, ((double) transformed.x + offset_x) * scale);
     polygon.getPoints().set((i * 2) + 1, (((double) transformed.y * -1) + offset_Y) * scale);

     }
     }
     return polygon;
     }

     @Override
     public boolean providesNodeFor(Body body, PolygonShape shape) {
     // dummy, because this will never be asked for
     return (body.getUserData() instanceof FlipperInfo);
     }
    
     */
}
