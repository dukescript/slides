/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test;

import com.sun.javafx.perf.PerformanceTracker;
import de.eppleton.jbox2d.test.decoration.BackPanel;
import de.eppleton.jbox2d.rendering.NodeManager;
import de.eppleton.jbox2d.rendering.NodeProvider;
import de.eppleton.jbox2d.test.decoration.PinballMachineCover;
import java.io.IOException;
import java.util.WeakHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.CacheHint;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
//import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.SVGPath;
import javafx.util.Duration;
import org.jbox2d.collision.shapes.Shape;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyType;
import org.jbox2d.dynamics.World;

/**
 *
 * @author eppleton
 */
public class PinballView extends Region implements DukeNoseLighter {

    private WeakHashMap<Body, Node> nodes = new WeakHashMap<Body, Node>();
    private World world;
    private Timeline timeline;
    private double x_offset, y_offset;
    private float scale;
    private Label score;
//    private PinballMachineCover cover;
    private BackPanel backPanel;
    private boolean coverOn = false;
    private boolean coverBehind = false;
    private Parent root = null;
    private SVGPath dukeNose;
    private Color pale = Color.color(.4, 0, 0);
    private Rectangle background;

    public PinballView(final PinballWorld world, double x_offset, double y_offset, float scale) {
        dukeNose = new SVGPath();
        dukeNose.setContent("M139.162,172.181c-1.95-18.251-19.12-25.421-35.661-23.168c-13.889,1.893-32.403,13.613-34.107,28.64\n"
                + "c-1.921,16.937,11.402,32.522,28.361,33.203c15.03,0.604,31.176-6.668,37.93-20.79\n"
                + "C138.415,184.362,139.482,178.488,139.162,172.181");
        dukeNose.
                setScaleX(1.2);
        dukeNose.setTranslateX(645);
        dukeNose.setTranslateY(35);
        dukeNose.setFill(pale);
        dukeNose.setStroke(Color.BLACK);
        dukeNose.setStrokeWidth(5);

        Image image = new Image(this.getClass().getResourceAsStream("purty_wood.png"));
        // ImagePattern imagePattern = new ImagePattern(image,0,0,10,10,false);

        try {
            FXMLLoader loader = new FXMLLoader(getClass().
                    getResource("Sample.fxml"));
            root = (Parent) loader.load();

            world.setDukeNoseLighter(this);
            double scaleFactorLid = scale / 130;
            root.setScaleX(scaleFactorLid);
            root.setScaleY(scaleFactorLid);
            root.setLayoutX(((scaleFactorLid * 450) - 450) / 2);
            root.setLayoutY(((scaleFactorLid * 830) - 830) / 2);
        } catch (IOException ex) {
            Logger.getLogger(PinballView.class.getName()).
                    log(Level.SEVERE, null, ex);
        }
        // Show Score and Level
        score = new Label("0");
        //this.getStyleClass().add("playfield");
        world.scoreProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue o, Object oldVal,
                    Object newVal) {
                score.setText("" + newVal);
            }
        });
        this.x_offset = x_offset;
        this.y_offset = y_offset;
        this.scale = scale;
        this.world = world;
        score.setLayoutX((x_offset + 150) * scale);
        score.setLayoutY((y_offset + 500) * scale);
//        cover = new PinballMachineCover(445, 830);


        backPanel = new BackPanel(445, 830);
        initStaticBodies();
        // start the world
        timeline = new Timeline();
        timeline.setCycleCount(Timeline.INDEFINITE);
        Duration duration = Duration.millis(1000 / 60);

        EventHandler<ActionEvent> onFinished = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent t) {

                world.step(1.0f / 60.f, 1, 1);
                updateBodies();
            }
        };

        KeyFrame keyFrame = new KeyFrame(duration, onFinished, null, null);
        timeline.getKeyFrames().add(keyFrame);
        timeline.play();

    }

    private void updateBodies() {

        Body nextBody = world.getBodyList();
        while (nextBody != null) {
            if (nextBody.m_type != BodyType.STATIC) { // don't update static bodies
                Shape shape = nextBody.getFixtureList().getShape();
                NodeProvider nodeProvider = NodeManager.
                        getNodeProvider(nextBody, shape);
                Node n = nodes.get(nextBody);
                n = nodeProvider.
                        configureNode(n, nextBody, shape, x_offset, y_offset, scale);//, transform);
                if ("ball".equals(nextBody.getUserData())) {
                    double layoutY = n.getLayoutY();
                    double transY = ((getHeight() / 2) - layoutY);

                    if (transY < 0 && transY > -1100) {
                        if (getTranslateY() != transY) {
                            setTranslateY(transY);
                        }
                    }

                    /*  double clipHeight = boundsInParent.getMaxY() - boundsInParent.
                     getMinY();
                     System.out.println("clipHeight " + clipHeight);
                     if (layoutY > boundsInParent.getMinY() + (clipHeight / 4)) {
                     setTranslateY((getHeight() / 2) - layoutY);
                     }
                     if (layoutY < boundsInParent.getMaxY() - (clipHeight / 4)) {
                        
                     }*/
                }
                if (n != null && n.getParent() == null) { // check if this node is new
                    initStaticBodies();
                }
            }
            nextBody = nextBody.getNext();
        }
    }

    public void initStaticBodies() {
        nodes.clear();
        getChildren().clear();
        // getChildren().add(backPanel);
        if (coverOn && coverBehind) {
            getChildren().addAll(root, dukeNose);
        }

        Body nextBody = world.getBodyList();
        while (nextBody != null) {
            if (nextBody.m_type == BodyType.STATIC) {
                Shape shape = nextBody.getFixtureList().getShape();
                NodeProvider nodeProvider = NodeManager.
                        getNodeProvider(nextBody, shape);
                Node n = nodes.get(nextBody);
                n = nodeProvider.
                        configureNode(n, nextBody, shape, x_offset, y_offset, scale);//, transform);
                if (n != null && n.getParent() == null) { // check if this node is new
                    getChildren().add(n);
                    nodes.put(nextBody, n);
                }
            }
            nextBody = nextBody.getNext();
        }
        nextBody = world.getBodyList();
        while (nextBody != null) {
            if (nextBody.m_type != BodyType.STATIC) { // don't update static bodies
                Shape shape = nextBody.getFixtureList().getShape();
                NodeProvider nodeProvider = NodeManager.
                        getNodeProvider(nextBody, shape);
                Node n = nodes.get(nextBody);
                n = nodeProvider.
                        configureNode(n, nextBody, shape, x_offset, y_offset, scale);//, transform);
                if (n != null && n.getParent() == null) { // check if this node is new
                    getChildren().add(n);
                    nodes.put(nextBody, n);
                }
            }
            nextBody = nextBody.getNext();
        }
        if (coverOn & !coverBehind) {
            getChildren().addAll(root, dukeNose);
        }
        getChildren().addAll(score);
    }

    public boolean isCoverBehind() {
        return coverBehind;
    }

    public void setCoverBehind(boolean coverBehind) {
        this.coverBehind = coverBehind;
        initStaticBodies();
    }

    public void putCoverOn(boolean cover) {
        coverOn = cover;
        initStaticBodies();
    }

    public boolean isCoverOn() {
        return coverOn;
    }

    public void addNode(Node node) {
        getChildren().add(node);
    }

    @Override
    public void lightUp(boolean light) {
        dukeNose.setFill(light ? Color.RED : pale);
    }
}
