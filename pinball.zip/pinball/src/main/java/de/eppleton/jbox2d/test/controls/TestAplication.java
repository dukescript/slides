/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.paint.RadialGradientBuilder;
import javafx.scene.shape.RectangleBuilder;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.transform.Scale;
import javafx.scene.transform.Transform;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;

/**
 *
 * @author eppleton
 */
public class TestAplication extends Application {

    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
//        RectangleBuilder.create().stroke
        primaryStage.setTitle("Test Bodies");
        Group root = new Group();
        Translate translate = new Translate(120, 120);
        Scale scaler = new Scale(5, 5);
        Transform[] transform = new Transform[]{
            translate, 
            scaler};
        root.getTransforms().addAll(transform);

        Scene scene = new Scene(root, 400, 300, Color.WHITE);
        MetalBall ball = new MetalBall();
        ball.setRadius(10);
//        Bumper bumper = new Bumper("bumper");
//       bumper.getTransforms().add(new Scale(.1, .1));
        root.getChildren().add(ball);
        root.getStylesheets().add(TestAplication.class.getResource("../resources/bumper.css").
                toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
