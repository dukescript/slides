/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.Parent;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.StackPaneBuilder;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.scene.text.TextBuilder;
import org.jbox2d.collision.shapes.ChainShape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;

/**
 *
 * @author eppleton
 */
public class Rollover extends Parent {

    public Rollover(RolloverInfo info, float scaleFactor, Body body, double offset_x, double offset_Y, ChainShape shape) {


        Vec2 vec2 = shape.m_vertices[0];
        Vec2 transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);

        double x0 = (((double) transformed.x + offset_x) * scaleFactor);
        double y0 = (((double) transformed.y * -1) + offset_Y) * scaleFactor;

        vec2 = shape.m_vertices[1];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);

        double x1 = (((double) transformed.x + offset_x) * scaleFactor);
        double y1 = (((double) transformed.y * -1) + offset_Y) * scaleFactor;

        vec2 = shape.m_vertices[2];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);

        double x2 = (((double) transformed.x + offset_x) * scaleFactor);
        double y2 = (((double) transformed.y * -1) + offset_Y) * scaleFactor;

        vec2 = shape.m_vertices[3];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);

        double x3 = (((double) transformed.x + offset_x) * scaleFactor);
        double y3 = (((double) transformed.y * -1) + offset_Y) * scaleFactor;
        double width = (x2 - x0);
        double height = (y0 - y1);
        double rectWidth = width * .1;
        double cutoutInsets = width * .15;
        double centerX = x0 + (width / 2) - (rectWidth / 2);
        Rectangle wire = RectangleBuilder.create().x(centerX).y(y1).height(y0 - y1).
                width(rectWidth).build();

//        Rectangle outerBoxShape = RectangleBuilder.create().x(x0).y(y0 - (1.2 * width)).
//                width(width).height(y1 - y0 + (2.2 * width)).build();
        Rectangle outerBoxShape = RectangleBuilder.create().x(x0).y(y1 - (width)).
                width(width).height(height + (width * 1.5)).fill(Color.BLUE).
                build();
        MoveTo pos0 = new MoveTo(x0 + (width / 2) - cutoutInsets, y0 + cutoutInsets);
        LineTo line1 = new LineTo(x1 + (width / 2) - cutoutInsets, y1 - cutoutInsets);
        QuadCurveTo curve = new QuadCurveTo(x0 + (width / 2), y1 - (cutoutInsets * 2), x0 + (width / 2) + cutoutInsets, y1 - cutoutInsets);
        LineTo line2 = new LineTo(x1 + (width / 2) + cutoutInsets, y0 + cutoutInsets);
        QuadCurveTo curve2 = new QuadCurveTo(x0 + (width / 2), y0 + (cutoutInsets * 2), x0 + (width / 2) - cutoutInsets, y0 + cutoutInsets);
        Path path = PathBuilder.create().elements(pos0, line1, curve, line2, curve2).
                build();//,curve,line2,curve2).build();
        path.setFill(Color.BISQUE);
        Shape background = Path.subtract(outerBoxShape, path);
        background.setFill(Color.BLUE);
        background.setStrokeType(StrokeType.INSIDE);
        background.setStroke(Color.BLACK);
        final Circle circle = CircleBuilder.create().//centerX(x0 + (width / 2)).centerY(y0 - (1.2*width)).
                radius(width / 3).fill(Color.CORAL).stroke(Color.BLACK).build();
        Text text = TextBuilder.create().text(info.getText()).build();
        StackPane stackPane = StackPaneBuilder.create().layoutX(x0 + (width / 2) - (width / 3)).
                layoutY(y1 - (width / 2) - (width / 1.5)).build();
        stackPane.getChildren().addAll(circle, text);
        getChildren().addAll(background, stackPane, wire);

        info.litProperty().addListener(new ChangeListener<Boolean>() {

            @Override
            public void changed(ObservableValue<? extends Boolean> ov, Boolean t, Boolean t1) {
                circle.setFill(t1 ? Color.CORAL : Color.DARKRED);
            }
        });

    }
}
