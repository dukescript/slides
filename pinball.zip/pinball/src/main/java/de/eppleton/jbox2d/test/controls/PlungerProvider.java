/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import de.eppleton.jbox2d.rendering.PolygonProvider;
import de.eppleton.jbox2d.test.controls.PlungerProvider.Plunger;
import javafx.scene.Parent;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.DropShadowBuilder;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.RectangleBuilder;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;

/**
 *
 * @author eppleton
 */
public class PlungerProvider implements PolygonProvider<Plunger> {

    @Override
    public Plunger configureNode(Plunger plunger, Body body, PolygonShape shape, double offset_x, double offset_Y, float scale) {//, Transform[] transform) {
        Vec2 vec2 = shape.getVertex(3);
        Vec2 transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
        double x3 = transformed.x;
        double y3 = transformed.y;
        if (plunger == null) {
             vec2 = shape.getVertex(0);
            transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
            double x0 = transformed.x;
            double y0 = transformed.y;
            vec2 = shape.getVertex(1);
            transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
            double x1 = transformed.x;
            vec2 = shape.getVertex(2);
            transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
            double y2 = transformed.y;
            double height = (y2-y0)* scale;
            double width = (x1 -x0) * scale;
            plunger = new Plunger(width, height);
            
            for (int i = 0; i < shape.getVertexCount(); i++) {
                Vec2 vec = shape.getVertex(i);
                Vec2 transf = org.jbox2d.common.Transform.mul(body.m_xf, vec);
               
            }
        }
        plunger.setLayoutX(((double) x3 + offset_x) * scale);
        plunger.setLayoutY((((double) y3 * -1) + offset_Y) * scale);
        return plunger;
    }

    @Override
    public boolean providesNodeFor(Body body, PolygonShape shape) {
        return "plunger".equals(body.getUserData());
    }

    public static class Plunger extends Parent {
DropShadow dropShadow = DropShadowBuilder.create().height(41).offsetX( 5 ).
                offsetY( 5 ).
                radius(10).width(21).
                build();

        private Plunger(double width, double height) {
            Circle c = new Circle(0, 0, 10,Color.RED);
            Rectangle tip = RectangleBuilder.create().effect(dropShadow).x(0).y(0).width(width).height(4).fill(Color.WHITESMOKE).build();
            Rectangle rod = RectangleBuilder.create().effect(dropShadow).x(width/4).y(4).width(width/2).height(height -4).fill(Color.LIGHTGRAY).build();
            getChildren().addAll(rod,tip);

        }
        
        
    }
}
