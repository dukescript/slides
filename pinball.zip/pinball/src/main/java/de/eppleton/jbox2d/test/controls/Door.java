/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

/**
 *
 * @author eppleton
 */
public class Door {

    private boolean clockwise = false;
    private boolean x_axis = false;

    public Door( boolean x_axis, boolean clockwise) {
        this.clockwise = clockwise;
        this.x_axis = x_axis;
    }

    public boolean isClockwise() {
        return clockwise;
    }

    public void setClockwise(boolean clockwise) {
        this.clockwise = clockwise;
    }

    public boolean isX_axis() {
        return x_axis;
    }

    public void setX_axis(boolean x_axis) {
        this.x_axis = x_axis;
    }
}
