/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.decoration;

import javafx.scene.Parent;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.*;

/**
 *
 * @author eppleton
 */
public final class BackPanel extends Parent {

    double width;
    double height;
    double leftSlingShotX = 58;
    double leftSlingshotY = 615;

    public BackPanel(double width, double height) {
        this.width = width;
        double fieldWidth = width - 40;
        this.height = height;

        
        Shape back =getBackGroundShape(leftSlingShotX,leftSlingshotY, fieldWidth, Color.ALICEBLUE);
        Shape smallFlipperShape = getSmallFlipperShape(260,320,140,Color.BLANCHEDALMOND);
        getChildren().addAll(back, smallFlipperShape
                );
    }
    
    public Shape getBackGroundShape(double x, double y,double fieldWidth, Paint fill){
    
        MoveTo start = new MoveTo(x, y);
        LineTo lineTo = new LineTo(x + 60, y + 30);
        QuadCurveTo curve = new QuadCurveTo((fieldWidth / 2), 500, fieldWidth - (x + 60), leftSlingshotY + 30);
        LineTo lieTo2 = new LineTo(fieldWidth - x, y);
        LineTo lineTo3 = new LineTo(fieldWidth - x, 140);
        CubicCurveTo curve2 = new CubicCurveTo( fieldWidth , 0, 0, 0,x, 140);

        Path p = new Path(start, lineTo, curve, lieTo2,lineTo3,curve2);
        p.setFill(fill);
        p.setStrokeWidth(0);
        return p;
    }
    
    public Shape getSmallFlipperShape(double x, double y,double fieldWidth, Paint fill){
    
        MoveTo start = new MoveTo(x, y);
        LineTo lineTo = new LineTo(x+ fieldWidth, y);
 
        LineTo lineTo3 = new LineTo(x+ fieldWidth, 140);
        CubicCurveTo curve2 = new CubicCurveTo( x+fieldWidth , 70, x, 70,x, 140);

        Path p = new Path(start, lineTo, lineTo3,curve2);
        p.setFill(fill);
        p.setStrokeWidth(0);
        return p;
    }
}
