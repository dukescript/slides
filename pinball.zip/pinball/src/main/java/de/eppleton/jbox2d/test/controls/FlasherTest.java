/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import de.eppleton.jbox2d.rendering.NodeManager;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

/**
 *
 * @author eppleton
 */
public class FlasherTest extends Application {

    public static void main(String[] args) {
        Application.launch(FlasherTest.class, args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        final Flasher flasher = new Flasher();
        Scene scene = new Scene(flasher);
        scene.setOnKeyPressed(
                new EventHandler<KeyEvent>() {

                    @Override
                    public void handle(KeyEvent ke) {
                        if (ke.getCode()
                                == KeyCode.A) {
                            flasher.switchOn(!flasher.isOn());
                        }
                    }
                });
        stage.setScene(scene);

        stage.show();
    }
}