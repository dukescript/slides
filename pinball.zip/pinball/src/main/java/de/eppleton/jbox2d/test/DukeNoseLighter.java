/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test;

/**
 *
 * @author eppleton
 */
public interface DukeNoseLighter {
    
    public void lightUp(boolean light);
    
}
