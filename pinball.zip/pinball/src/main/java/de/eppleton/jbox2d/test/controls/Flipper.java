/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import javafx.scene.Parent;
import javafx.scene.effect.*;
import javafx.scene.effect.Light.Distant;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.RotateBuilder;

/**
 *
 * @author eppleton
 */
public final class Flipper extends Parent {

    Rotate rotate;
    FlipperInfo flipperInfo;

    public Flipper(FlipperInfo flipperInfo, float scaleFactor) {
        
        this.flipperInfo = flipperInfo;
        boolean left = flipperInfo.left;
     
        if (!left) {
            getTransforms().add(new Rotate(180));
        }
        rotate = RotateBuilder.create().pivotX(flipperInfo.pivotX *scaleFactor).pivotY(flipperInfo.pivotY*scaleFactor).angle(75).
                build();
        DropShadow dropShadow = DropShadowBuilder.create().height(41).offsetX(left ? 5 : -5).
                offsetY(left ? 5 : -5).
                radius(10).width(21).
                build();

        getTransforms().add(rotate);
        float halfHeight = flipperInfo.getHeight()/2;
        float halfLength = flipperInfo.getLength()/2;
        MoveTo moveTo = new MoveTo( flipperInfo.pivotX*scaleFactor, -halfHeight *scaleFactor);
        LineTo lineTo = new LineTo( (halfLength - (halfHeight / 2)) *scaleFactor, -halfHeight *scaleFactor / 2);
        QuadCurveTo curveTo = QuadCurveToBuilder.create()
                .controlX( ( halfLength+( halfHeight /2))*scaleFactor).controlY(0).x( (halfLength - (halfHeight / 2))*scaleFactor).
                y( halfHeight *scaleFactor / 2).build();
        LineTo lineTo2 = new LineTo(flipperInfo.pivotX*scaleFactor, halfHeight*scaleFactor);
        QuadCurveTo curveTo2 = QuadCurveToBuilder.create()
                .controlX( (-halfLength-( halfHeight /2))*scaleFactor).controlY(0).x(flipperInfo.pivotX*scaleFactor).
                y(-halfHeight*scaleFactor).build();
        Path one = PathBuilder.create().
                effect(dropShadow).fill(Color.BLACK).elements(moveTo,lineTo,curveTo,lineTo2,curveTo2).
                strokeWidth(0).
                build();
       
        Path two = PathBuilder.create().effect(InnerShadowBuilder.create().choke(0.006993006993006994).
                build()).
                fill(Color.ORANGERED).elements(moveTo,lineTo,curveTo,lineTo2,curveTo2).
                strokeWidth(0).
                build();
        
        Path three = PathBuilder.create().
                effect(DropShadowBuilder.create().offsetX(left ? 10 : -10).
                offsetY(left ? 5 : -5).
                radius(20).width(41).
                build()).scaleX(0.9).scaleY(0.6).
                fill(Color.WHITE).elements(moveTo,lineTo,curveTo,lineTo2,curveTo2).
                strokeWidth(0).
                build();
        
        /*
        SVGPath one = SVGPathBuilder.create().
                content(path).
                effect(dropShadow).fill(Color.BLACK).scaleX(1.068399768813899).
                scaleY(1.5053902586895043).
                build();
        SVGPath two = SVGPathBuilder.create().
                content(
                path).
                effect(InnerShadowBuilder.create().choke(0.06993006993006994).
                build()).fill(Color.ORANGERED).scaleX(1.068399768813899).scaleY(1.5053902586895043).
                build();
        SVGPath three = SVGPathBuilder.create().
                content(path
                ).
                effect(DropShadowBuilder.create().offsetX(left ? 10 : -10).
                offsetY(left ? 5 : -5).
                radius(20).width(41).
                build()).fill(Color.WHITE).scaleX(0.9705171834582451).scaleY(1.0253883427368171).
                build();*/
        Distant distantLight = new Light.Distant();
        distantLight.setAzimuth(225.0);
        InnerShadow innerShadow = InnerShadowBuilder.create().choke(0.006993006993006994).
                build();
        Path four = PathBuilder.create().
                elements(moveTo,lineTo,curveTo,lineTo2,curveTo2).
                effect(LightingBuilder.create().specularConstant(2.0).
                specularExponent(17.142857142857146).
                contentInput(innerShadow).light(distantLight).bumpInput(innerShadow).
                build()).fill(Color.WHITE).
                scaleX(0.9).scaleY(0.6).build();

        getChildren().addAll( one, two, three, four);//, three, four, five);
        

    }

    public void rotate(float angle) {
        rotate.setAngle(-Math.toDegrees(angle));
    }

    
}
