package de.eppleton.jbox2d.test;

import com.sun.javafx.perf.PerformanceTracker;
import de.eppleton.jbox2d.rendering.CircleProvider;
import de.eppleton.jbox2d.rendering.NodeManager;
import de.eppleton.jbox2d.test.controls.*;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Pinball extends Application {
    // -Dprism.dirtyopts=false

    private PinballWorld pinballWorld;
    private boolean useBumperProvider = true;
    BumperNodeProvider bumperProvider = new BumperNodeProvider();
    private boolean useBallProvider = true;
    CircleProvider ballProvider = new MetalBallProvider();
    private boolean useFlipperProvider = true;
    FlipperProvider flipperProvider = new FlipperProvider();
    private boolean useLaneProvider = true;
    LaneProvider laneProvider = new LaneProvider();
    private boolean useLauncherProvider = true;
    LauncherProvider launcherProvider = new LauncherProvider();
    private boolean useRolloverProvider = true;
    RolloverProvider rolloverProvider = new RolloverProvider();
    private boolean usePlungerProvider = true;
    PlungerProvider plungerProvider = new PlungerProvider();
    
    public static void main(String[] args) {
        Application.launch(args);
    }
    private float angle;
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("JavaFX + Box2D");
        pinballWorld = new PinballWorld();
        final PinballView view = new PinballView(pinballWorld, .05, 5.9, 300);
        view.getStylesheets().add(Pinball.class.
                getResource("resources/bumper.css").toExternalForm());
        StackPane stackPane = new StackPane(view);
        final Scene scene = new Scene(stackPane, 1000, 830);
        Label fps = getPerformanceTrackerLabel(scene);
        StackPane.setAlignment(fps, Pos.TOP_LEFT);
        stackPane.getChildren().add(fps);
        NodeManager.addCircleProvider(ballProvider);
        NodeManager.addPolygonProvider(flipperProvider);
        NodeManager.addCircleProvider(bumperProvider);
        NodeManager.addChainProvider(laneProvider);
        NodeManager.addChainProvider(launcherProvider);
        NodeManager.addChainProvider(rolloverProvider);
        NodeManager.addPolygonProvider(plungerProvider);
        view.putCoverOn(true);
        scene.setOnKeyPressed(
                new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent ke) {
                if (ke.getCode()
                        == KeyCode.A) {
                    if (!useBallProvider) {
                        NodeManager.addCircleProvider(ballProvider);
                    } else {
                        NodeManager.removeProvider(ballProvider);
                    }
                    useBallProvider = !useBallProvider;
                    view.initStaticBodies();
                }
                if (ke.getCode()
                        == KeyCode.S) {
                    if (!useFlipperProvider) {
                        
                        NodeManager.addPolygonProvider(flipperProvider);
                    } else {
                        NodeManager.removeProvider(flipperProvider);
                    }
                    useFlipperProvider = !useFlipperProvider;
                    view.initStaticBodies();
                }
                if (ke.getCode()
                        == KeyCode.D) {
                    if (!useBumperProvider) {
                        NodeManager.addCircleProvider(bumperProvider);
                    } else {
                        NodeManager.removeProvider(bumperProvider);
                    }
                    useBumperProvider = !useBumperProvider;
                    view.initStaticBodies();
                    
                }
                if (ke.getCode()
                        == KeyCode.F) {
                    
                    view.initStaticBodies();
                    
                }
                if (ke.getCode()
                        == KeyCode.G) {
                    
                    if (!useLaneProvider) {
                        NodeManager.addChainProvider(laneProvider);
                    } else {
                        NodeManager.removeProvider(laneProvider);
                    }
                    useLaneProvider = !useLaneProvider;
                    view.initStaticBodies();
                }
                if (ke.getCode()
                        == KeyCode.H) {
                    
                    if (!useLauncherProvider) {
                        NodeManager.addChainProvider(launcherProvider);
                    } else {
                        NodeManager.removeProvider(launcherProvider);
                    }
                    useLauncherProvider = !useLauncherProvider;
                    view.initStaticBodies();
                }
                
                if (ke.getCode()
                        == KeyCode.J) {
                    
                    if (!useRolloverProvider) {
                        NodeManager.addChainProvider(rolloverProvider);
                    } else {
                        NodeManager.removeProvider(rolloverProvider);
                    }
                    useRolloverProvider = !useRolloverProvider;
                    view.initStaticBodies();
                }
                
                if (ke.getCode() == KeyCode.P) {
                    
                    if (!usePlungerProvider) {
                        NodeManager.addPolygonProvider(plungerProvider);
                    } else {
                        NodeManager.removeProvider(plungerProvider);
                    }
                    usePlungerProvider = !usePlungerProvider;
                    view.initStaticBodies();
                }
                if (ke.getCode() == KeyCode.B) {
                    pinballWorld.addBall();
                }
                
                if (ke.getCode() == KeyCode.C) {
                    
                    view.putCoverOn(!view.isCoverOn());
                }
                
                if (ke.getCode() == KeyCode.V) {
                    
                    view.setCoverBehind(!view.isCoverBehind());
                }
                
                if (ke.getCode()
                        == KeyCode.LEFT) {
                    pinballWorld.leftButtonDown(true);
                    pinballWorld.loopJavaRollovers();
                }
                if (ke.getCode()
                        == KeyCode.RIGHT) {
                    pinballWorld.rightButtonDown(true);
                    pinballWorld.loopJavaRollovers();
                    
                }
                if (ke.getCode()
                        == KeyCode.UP) {
                    pinballWorld.shoot(false);
                }
                /*if (ke.getCode()
                         == KeyCode.M) {
                         flipper.setMagnetOn(true);
                         }*/
            }
        });
        
        scene.setOnKeyReleased(
                new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent ke) {
                
                if (ke.getCode()
                        == KeyCode.LEFT) {
                    pinballWorld.leftButtonDown(false);
                }
                if (ke.getCode()
                        == KeyCode.RIGHT) {
                    pinballWorld.rightButtonDown(false);
                }
                if (ke.getCode()
                        == KeyCode.UP) {
                    pinballWorld.shoot(true);
                }
                
            }
        });
//        ScenicView.show(scene);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    private Label getPerformanceTrackerLabel(Scene scene) {
        final Label label = new Label("FPS");
        final PerformanceTracker sceneTracker = PerformanceTracker.getSceneTracker(scene);
        AnimationTimer timeline = new AnimationTimer(){
            public void handle(long t) {
                label.setText(String.format("CFPS: %.3f AFPS: %.3f", sceneTracker.getInstantFPS(), sceneTracker.getAverageFPS()));
            }
        };
        
       
        timeline.start();
        return label;
    }
}
