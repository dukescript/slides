/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import javafx.scene.CacheHint;
import javafx.scene.Parent;
import javafx.scene.effect.Glow;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.LinearGradientBuilder;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.shape.CircleBuilder;
import javafx.scene.shape.SVGPath;
import javafx.scene.shape.SVGPathBuilder;
import javafx.scene.text.FontBuilder;
import javafx.scene.text.Text;
import javafx.scene.text.TextBuilder;
import javafx.scene.transform.Scale;

/**
 *
 * @author eppleton
 */
public class Flasher extends Parent {

    private Color backOff;
    private final Color baseColor;
    private Circle innerRing;
    private Circle outerRing;
    private final double radius;
    private StackPane stackPane;
    private SVGPath star;
    private SVGPath star2;
    private final Text text;
    private Glow glow = new Glow(1);
    LinearGradient linearGradient;
//RadialGradient radialGradient = RadialGradientBuilder.create().centerX(0.505).centerY(0.525).radius(1.0).cycleMethod(CycleMethod.NO_CYCLE).stops(new Stop(0.0,Color.web("#F9FF00",0.521276593208313)),new Stop(0.5035460992907801,Color.web("#F9FF00",1.0)),new Stop(1.0,Color.web("#F9FF00",0.51241135597229))).build();
    private boolean on;

    public Flasher() {
        this(Color.RED, 100, TextBuilder.create().text("1").font(FontBuilder.
                create().name("Bitstream Vera Sans").size(100).build()).build());
    }

    public Flasher(Color baseColor, double radius, Text text) {
        double scaleStar = radius / 100;
        double strokeWidthFactor = .16;
        this.baseColor = baseColor;
        this.radius = radius;
        this.text = text;
        stackPane = new StackPane();

        linearGradient = LinearGradientBuilder.create().startX(0.5).
                startY(0.0).endX(0.55).endY(1.0).cycleMethod(CycleMethod.NO_CYCLE).
                stops(new Stop(0.0, baseColor), new Stop(0.5035460992907801, Color.
                        web("#F9FF00", 1.0)), new Stop(1.0, Color.web("#F9FF00", 0.51241135597229))).
                build();
        Color derivedColor = baseColor.deriveColor(0.0, 1.0, 1.0, 0.7);
        backOff = Color.BLACK.deriveColor(0.0, 1.0, 1.0, 0.1);
        star = SVGPathBuilder.create().scaleX(scaleStar).scaleY(scaleStar).
                fill(backOff).
                stroke(backOff).content("M 62.857142,397.36219 22.721529,353.09235 39.651018,410.39923 17.077056,355.072 13.385464,414.71308 11.095905,355.00174 -12.771506,409.78342 5.4994929,352.89004 -35.664977,396.20485 0.96282836,348.99161 -52.533657,375.61514 -1.9668995,343.77665 -61.342934,350.49771 -2.9363223,337.87417 -61.030281,323.8821 -1.8285133,331.99609 -51.633407,298.97854 1.2229093,326.85139 -34.285714,278.79076 5.849899,323.0606 -11.07959,265.75372 l 22.573962,55.32723 3.691592,-59.64108 2.289559,59.71134 23.867411,-54.78168 -18.270999,56.89338 41.16447,-43.31481 -36.627805,47.21324 53.496485,-26.62353 -50.566757,31.83849 59.376035,-6.72106 -58.406612,12.62354 58.093958,13.99208 -59.201767,-8.11399 49.804893,33.01755 -52.856316,-27.87286 z").
                build();
        star2 = SVGPathBuilder.create().effect(new Glow()).scaleX(scaleStar).
                scaleY(scaleStar).fill(baseColor.deriveColor(60, 1.0, 1.0, 1)).
                content(
                        "M 62.857142,397.36219 22.721529,353.09235 39.651018,410.39923 17.077056,355.072 13.385464,414.71308 11.095905,355.00174 -12.771506,409.78342 5.4994929,352.89004 -35.664977,396.20485 0.96282836,348.99161 -52.533657,375.61514 -1.9668995,343.77665 -61.342934,350.49771 -2.9363223,337.87417 -61.030281,323.8821 -1.8285133,331.99609 -51.633407,298.97854 1.2229093,326.85139 -34.285714,278.79076 5.849899,323.0606 -11.07959,265.75372 l 22.573962,55.32723 3.691592,-59.64108 2.289559,59.71134 23.867411,-54.78168 -18.270999,56.89338 41.16447,-43.31481 -36.627805,47.21324 53.496485,-26.62353 -50.566757,31.83849 59.376035,-6.72106 -58.406612,12.62354 58.093958,13.99208 -59.201767,-8.11399 49.804893,33.01755 -52.856316,-27.87286 z").
                build();
        innerRing = CircleBuilder.create().effect(new Glow()).fill(Color.TRANSPARENT).
                radius(radius - (radius * (strokeWidthFactor * 1.2))).
                stroke(baseColor).
                strokeWidth(radius * strokeWidthFactor).build();
        outerRing = CircleBuilder.create().radius(radius).stroke(Color.BLACK).
                fill(derivedColor).
                strokeWidth(radius * strokeWidthFactor).build();
        stackPane.getChildren().addAll(star, innerRing, outerRing, text);
        getChildren().addAll(stackPane);
    }

    public void switchOn(boolean on) {
        stackPane.getChildren().clear();
        if (on) {
            star.setEffect(glow);
            star.setFill(linearGradient);
            stackPane.getChildren().addAll(star);
        } else {
            star.setFill(backOff);
            stackPane.getChildren().addAll(star, innerRing, outerRing, text);
        }
        this.on = on;
    }

    boolean isOn() {
        return on;
    }
}
