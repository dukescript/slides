/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.rendering;

import de.eppleton.jbox2d.rendering.NodeManager;
import de.eppleton.jbox2d.rendering.NodeProvider;
import java.util.WeakHashMap;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.layout.Region;
import javafx.scene.transform.Scale;
import javafx.scene.transform.Transform;
import javafx.scene.transform.Translate;
import javafx.util.Duration;
import org.jbox2d.collision.shapes.Shape;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.World;

/**
 *
 * @author eppleton
 */
public class WorldView extends Region {

    private WeakHashMap<Body, Node> nodes = new WeakHashMap<Body, Node>();
    private World world;
    private Timeline timeline;
    private Transform[] transform;
    private double x_offset, y_offset;
    private float scale;

    public WorldView(final World world, double x_offset, double y_offset, float scale) {
        this.x_offset = x_offset;
        this.y_offset = y_offset;
        this.scale = scale;

        getStyleClass().add("background");
        Translate translate = new Translate(x_offset, y_offset);
        Scale scaler = new Scale(scale, scale);
        transform = new Transform[]{translate, scaler};
        //getTransforms().addAll(transform);
        this.world = world;
        timeline = new Timeline();
        timeline.setCycleCount(Timeline.INDEFINITE);
        Duration duration = Duration.seconds(1d / 60d);

        EventHandler<ActionEvent> onFinished = new EventHandler<ActionEvent>() {

            public void handle(ActionEvent t) {
                world.step(1.0f / 60.f, 1, 1);

                updateBodies();
            }
        };

        KeyFrame keyFrame = new KeyFrame(duration, onFinished, null, null);
        timeline.getKeyFrames().add(keyFrame);
        timeline.play();
    }

    private void updateBodies() {
        Body nextBody = world.getBodyList();
        while (nextBody != null) {
            Shape shape = nextBody.getFixtureList().getShape();
            NodeProvider nodeProvider = NodeManager.getNodeProvider(nextBody, shape);
            Node n = nodes.get(nextBody);
            n = nodeProvider.configureNode(n, nextBody, shape, x_offset, y_offset, scale);//, transform);
            if (n != null && n.getParent() == null) { // check if this node is new
                getChildren().add(n);
                nodes.put(nextBody, n);
            }
            nextBody = nextBody.getNext();
        }
    }
}
