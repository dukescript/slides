/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import javafx.scene.CacheHint;
import javafx.scene.Parent;
import javafx.scene.effect.BoxBlur;
import javafx.scene.effect.BoxBlurBuilder;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.DropShadowBuilder;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextBuilder;
import javafx.scene.transform.Scale;

/**
 *
 * @author eppleton
 */
public class Bumper extends Parent {

    private BoxBlur boxBlur = BoxBlurBuilder.create().height(2).width(2).build();
    private DropShadow dropShadow;

    public Bumper(String configString) {

        dropShadow = DropShadowBuilder.create().height(173).width(173).
                offsetX(20).offsetY(25).radius(85).build();
        Circle one = CircleBuilder.create().fill(Color.WHITE).radius(100).
                stroke(Color.BLACK).strokeType(StrokeType.INSIDE).
                effect(dropShadow).
                build();
        Circle two = CircleBuilder.create().fill(Color.WHITE).radius(100).
                stroke(Color.BLACK).strokeType(StrokeType.INSIDE).
                styleClass("circle").effect(boxBlur).build();
        Circle three = CircleBuilder.create().fill(Color.WHITE).radius(100).
                stroke(Color.BLACK).strokeType(StrokeType.INSIDE).
                styleClass("circle-highlight").build();
        Circle four = CircleBuilder.create().fill(Color.WHITE).radius(82).
                stroke(Color.BLACK).strokeType(StrokeType.INSIDE).
                styleClass("circle").effect(boxBlur).build();
        Circle five = CircleBuilder.create().fill(Color.WHITE).radius(82).
                stroke(Color.BLACK).strokeType(StrokeType.INSIDE).
                styleClass("circle-highlight").effect(boxBlur).build();
        Circle six = CircleBuilder.create().fill(Color.TRANSPARENT).radius(56).
                stroke(Color.RED).strokeType(StrokeType.INSIDE).strokeWidth(3.1).
                effect(boxBlur).build();
        Circle seven = CircleBuilder.create().fill(Color.TRANSPARENT).radius(49).
                stroke(Color.RED).strokeType(StrokeType.INSIDE).strokeWidth(3.1).
                effect(boxBlur).build();
        Circle eight = CircleBuilder.create().radius(42).
                fill(Color.color(0.322, 0, 1)).strokeWidth(0).effect(boxBlur).
                build();
        Polygon nine = PolygonBuilder.create().fill(Color.WHITE).
                strokeType(StrokeType.INSIDE).
                points(35.0, 120.5, 37.9, 129.1, 46.9, 129.1, 39.7, 134.5, 42.3, 143.1, 35.0, 139.0, 27.7, 143.1, 30.3, 134.5, 23.1, 129.1, 32.1, 129.1).
                scaleX(2.5).scaleY(2.5).layoutX(-35).layoutY(-140).build();
        Text ten = TextBuilder.create().text("100").
                font(Font.font("BlackoakStd", 16)).fill(Color.WHITE).
                strokeWidth(1.8).stroke(Color.RED).layoutX(-15).layoutY(0).
                build();
        //            getChildren().addAll(one, two, three, four, five, six, seven, eight);
        getChildren().addAll(one, two, three, four, five, six, seven, eight, nine, ten);

    }
    Scale scale;

    void setRadius(float f) {
        if (scale == null) {
            scale = new Scale();
            getTransforms().add(scale);
        }
        scale.setX(f/100);
        scale.setY(f/100);
    }
}
