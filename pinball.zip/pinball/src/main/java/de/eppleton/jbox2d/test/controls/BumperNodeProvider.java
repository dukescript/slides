/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import de.eppleton.jbox2d.rendering.CircleProvider;
import javafx.scene.Node;
import org.jbox2d.collision.shapes.CircleShape;
import org.jbox2d.dynamics.Body;

/**
 *
 * @author eppleton
 */
public class BumperNodeProvider implements CircleProvider< Bumper> {

    public BumperNodeProvider() {
    }

    @Override
    public Node configureNode(Bumper n, Body body, CircleShape shape, double offset_x, double offset_Y, float scale) {//, Transform [] transforms) {
        if (n == null) {
            n = new Bumper((String) body.getUserData());
            n.setRadius(shape.m_radius *scale);
        }
        n.setLayoutX( (body.getPosition().x + offset_x) * scale);
        n.setLayoutY(((body.getPosition().y * -1) + offset_Y) * scale);
        return n;
    }

    @Override
    public boolean providesNodeFor(Body body, CircleShape shape) {
        if ("bumper".equals(
                body.getUserData()) || "bumper500".equals(
                body.getUserData()) || "bumper1000".equals(
                body.getUserData())) {
            return true;
        }
        return false;
    }
}
