/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import javafx.scene.CacheHint;
import javafx.scene.Parent;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.DropShadowBuilder;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
//import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.*;
import org.jbox2d.collision.shapes.ChainShape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;

/**
 *
 * @author eppleton
 */
public class Launcher extends Parent {

   DropShadow dropShadow = DropShadowBuilder.create().offsetX(8).
            offsetY(8).
            radius(25).
            build();

    public Launcher(float scaleFactor, Body body, double offset_x, double offset_Y, ChainShape shape) {

        
        Vec2 vec2 = shape.m_vertices[0];
        Vec2 transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);

        MoveTo moveTo = new MoveTo((((double) transformed.x + offset_x) * scaleFactor), (((double) transformed.y * -1) + offset_Y) * scaleFactor);

        vec2 = shape.m_vertices[1];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
        LineTo lineTo1 = new LineTo(((double) transformed.x + offset_x) * scaleFactor, (((double) transformed.y * -1) + offset_Y) * scaleFactor);

        vec2 = shape.m_vertices[2];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
        LineTo lineTo2 = new LineTo(((double) transformed.x + offset_x) * scaleFactor, (((double) transformed.y * -1) + offset_Y) * scaleFactor);

        vec2 = shape.m_vertices[3];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
        LineTo lineTo3 = new LineTo((((double) transformed.x + offset_x) * scaleFactor), (((double) transformed.y * -1) + offset_Y) * scaleFactor);


        vec2 = shape.m_vertices[0];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
        LineTo lineTo4 = new LineTo((((double) transformed.x + offset_x) * scaleFactor), (((double) transformed.y * -1) + offset_Y) * scaleFactor);
        Image image = new Image(this.getClass().getResourceAsStream("purty_wood.png"));
        
       // ImagePattern imagePattern = new ImagePattern(image,0,0,10,10,false);
      
        Path one = PathBuilder.create().
                effect(dropShadow).fill(Color.BURLYWOOD).elements(moveTo, lineTo1, lineTo2, lineTo3, lineTo4).
                strokeWidth(0).
                build();

        
        getChildren().addAll(one);
    }
}
