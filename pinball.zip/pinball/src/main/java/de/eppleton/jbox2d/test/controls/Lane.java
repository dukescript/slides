/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import javafx.scene.CacheHint;
import javafx.scene.Parent;
import javafx.scene.effect.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import org.jbox2d.collision.shapes.ChainShape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;

/**
 *
 * @author eppleton
 */
public class Lane extends Parent {

    DropShadow dropShadow = DropShadowBuilder.create().offsetX(6).
            offsetY(6).
            radius(25).
            build();

    public Lane(float scaleFactor, Body body, double offset_x, double offset_Y, ChainShape shape) {

        Vec2 vec2 = shape.m_vertices[0];
        Vec2 transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);

        Vec2 vec2_2 = shape.m_vertices[2];
        Vec2 transformed_2 = org.jbox2d.common.Transform.mul(body.m_xf, vec2_2);

        float laneWidth = (transformed_2.x - transformed.x) * scaleFactor;
        double inset = laneWidth * .15;

        Circle upperReboundRubberShadow = CircleBuilder.create().radius((laneWidth / 2)).
                centerX((((double) transformed.x + offset_x) * scaleFactor) + (laneWidth / 2)).
                centerY((((double) transformed.y * -1) + offset_Y) * scaleFactor).
                fill(Color.BLACK).effect(dropShadow).build();
        Circle upperReboundRubber = CircleBuilder.create().radius((laneWidth / 2)).
                centerX((((double) transformed.x + offset_x) * scaleFactor) + (laneWidth / 2)).
                centerY((((double) transformed.y * -1) + offset_Y) * scaleFactor).
                fill(Color.WHITE).build();
        Circle screw1 = CircleBuilder.create().radius(inset).
                centerX((((double) transformed.x + offset_x) * scaleFactor) + (laneWidth / 2)).
                centerY((((double) transformed.y * -1) + offset_Y) * scaleFactor).
                fill(Color.LIGHTGREY).build();
        MoveTo moveTo = new MoveTo((((double) transformed.x + offset_x) * scaleFactor) + inset, (((double) transformed.y * -1) + offset_Y) * scaleFactor);

        vec2 = shape.m_vertices[1];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
        double controlX = ((double) transformed.x + offset_x) * scaleFactor;
        double controlY = (((double) transformed.y * -1) + offset_Y) * scaleFactor;

        vec2 = shape.m_vertices[2];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
        QuadCurveTo curveTo = QuadCurveToBuilder.create().controlX(controlX).
                controlY(controlY).
                x((((double) transformed.x + offset_x) * scaleFactor) - inset).y((((double) transformed.y * -1) + offset_Y) * scaleFactor).
                build();

        vec2 = shape.m_vertices[3];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
        LineTo lineTo3 = new LineTo((((double) transformed.x + offset_x) * scaleFactor) - inset, (((double) transformed.y * -1) + offset_Y) * scaleFactor);

        vec2 = shape.m_vertices[4];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
        controlX = (((double) transformed.x + offset_x) * scaleFactor) - inset;
        controlY = (((double) transformed.y * -1) + offset_Y) * scaleFactor;

        vec2 = shape.m_vertices[5];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
        Circle lowerReboundRubberShadow = CircleBuilder.create().radius((laneWidth / 2)).
                centerX((((double) transformed.x + offset_x) * scaleFactor) + (laneWidth / 2)).
                centerY((((double) transformed.y * -1) + offset_Y) * scaleFactor).
                fill(Color.BLACK).effect(dropShadow).build();
        Circle lowerReboundRubber = CircleBuilder.create().radius((laneWidth / 2)).
                centerX((((double) transformed.x + offset_x) * scaleFactor) + (laneWidth / 2)).
                centerY((((double) transformed.y * -1) + offset_Y) * scaleFactor).
                fill(Color.WHITE).build();
        Circle screw2 = CircleBuilder.create().radius(inset).
                centerX((((double) transformed.x + offset_x) * scaleFactor) + (laneWidth / 2)).
                centerY((((double) transformed.y * -1) + offset_Y) * scaleFactor).
                fill(Color.LIGHTGREY).build();
        QuadCurveTo curveTo2 = QuadCurveToBuilder.create().controlX(controlX).
                controlY(controlY).
                x((((double) transformed.x + offset_x) * scaleFactor) + inset).y((((double) transformed.y * -1) + offset_Y) * scaleFactor).
                build();

        vec2 = shape.m_vertices[0];
        transformed = org.jbox2d.common.Transform.mul(body.m_xf, vec2);
        LineTo lineTo6 = new LineTo(inset + (((double) transformed.x + offset_x) * scaleFactor), (((double) transformed.y * -1) + offset_Y) * scaleFactor);

        Path one = PathBuilder.create().
                effect(dropShadow).fill(Color.BLACK).elements(moveTo, curveTo, lineTo3, curveTo2, lineTo6).
                strokeWidth(0).
                build();

        Path two = PathBuilder.create().
                fill(Color.RED).strokeWidth(0).elements(moveTo, curveTo, lineTo3, curveTo2, lineTo6).
                build();
        getChildren().addAll(upperReboundRubberShadow, upperReboundRubber, lowerReboundRubberShadow, lowerReboundRubber, one, two, screw1, screw2);
    }
}
