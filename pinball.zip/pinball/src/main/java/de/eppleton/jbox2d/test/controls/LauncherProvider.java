/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import de.eppleton.jbox2d.rendering.ChainProvider;
import javafx.scene.Node;
import org.jbox2d.collision.shapes.ChainShape;
import org.jbox2d.dynamics.Body;

/**
 *
 * @author eppleton
 */
public class LauncherProvider implements ChainProvider<Launcher> {

    @Override
    public Node configureNode(Launcher n, Body body, ChainShape shape, double offset_x, double offset_Y, float scale) {
        if (n == null) {
            n = new Launcher(scale,body, offset_x, offset_Y, shape);
        }
        return n;
    }

    @Override
    public boolean providesNodeFor(Body body, ChainShape shape) {
        if ("launcher".equals(
                body.getUserData())) {
            return true;
        }
        return false;
    }
}
