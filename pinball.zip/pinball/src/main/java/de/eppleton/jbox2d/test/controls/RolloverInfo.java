/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test.controls;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

/**
 *
 * @author eppleton
 */
public class RolloverInfo {

    private String text = "";
    private int value = 50;
    private BooleanProperty lit = new SimpleBooleanProperty(true);
    

    public RolloverInfo(String text) {
        this.text = text;
    }

    public boolean isLit() {
        return lit.getValue();
    }

    public void setLit(boolean islit) {
        lit.setValue(islit);
    }
    
    public BooleanProperty litProperty(){
        return lit;
    }
    

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
