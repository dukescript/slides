/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.eppleton.jbox2d.test;

import de.eppleton.jbox2d.builders.ChainShapeBuilder;
import de.eppleton.jbox2d.builders.CircleShapeBuilder;
import de.eppleton.jbox2d.builders.PolygonShapeBuilder;
import de.eppleton.jbox2d.test.controls.Door;
import de.eppleton.jbox2d.test.controls.FlipperInfo;
import de.eppleton.jbox2d.test.controls.RolloverInfo;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import org.jbox2d.callbacks.ContactImpulse;
import org.jbox2d.callbacks.ContactListener;
import org.jbox2d.collision.Manifold;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.*;
import org.jbox2d.dynamics.contacts.Contact;
import org.jbox2d.dynamics.joints.PrismaticJoint;
import org.jbox2d.dynamics.joints.PrismaticJointDef;
import org.jbox2d.dynamics.joints.RevoluteJointDef;

/**
 *
 * @author eppleton
 */
public class PinballWorld extends World implements ContactListener {

    private static int JAVA_POINTS = 200;
    private DukeNoseLighter dukeNoseLighter;

    public void setDukeNoseLighter(DukeNoseLighter dukeNoseLighter) {
        this.dukeNoseLighter = dukeNoseLighter;
    }
    private PolygonShape flipperBox;
    private float ball_radius = .07f;
    private Body rightFlipperBody;
    private Body leftFlipperBody;
    private Body rightSmallFlipperBody;
    private Body leftSmallFlipperBody;
    private PrismaticJoint joint;
    private Body dead;
    private float width = .02f;
    private IntegerProperty score = new SimpleIntegerProperty(0);
    private Vec2 insideDuke = new Vec2(2.5f, 4.7f);
    private Vec2 dropPoint = insideDuke;
    private Vec2 leftTrapPosition = new Vec2(0.14f, 2.87f);
    private Vec2 rightTrapPosition = new Vec2(2.9f, 2.9f);
    Vec2[] rolloverShape = new Vec2[]{new Vec2(-.1f, 0.1f), new Vec2(-.1f, .2f), new Vec2(.1f, .2f), new Vec2(.1f, 0.1f)};
    Vec2[] longrolloverShape = new Vec2[]{new Vec2(-.1f, 0f), new Vec2(-.1f, .2f), new Vec2(.1f, .2f), new Vec2(.1f, 0f)};
    Vec2[] laneShape = new Vec2[]{new Vec2(0f, .25f), new Vec2(0.05f, .3f),
        new Vec2(0.1f, .25f), new Vec2(.1f, .05f), new Vec2(.05f, 0f), new Vec2(.0f, .05f)};
    Vec2[] dukeTrap = new Vec2[]{new Vec2(0.05f, 0f), new Vec2(0.0f, 0.1f),
        new Vec2(0.08f, 0.4f), new Vec2(0.275f, .825f), new Vec2(0.48f, 0.4f),
        new Vec2(0.55f, 0.1f), new Vec2(0.5f, 0.0f), new Vec2(0.46f, 0.0f),
        new Vec2(.38f, .1f), new Vec2(.38f, .45f), new Vec2(.18f, .45f),
        new Vec2(.18f, .1f), new Vec2(.09f, .0f)};
    private IntegerProperty javaSolvedProperty = new SimpleIntegerProperty(0);

    public PinballWorld() {
        super(new Vec2(0, -5.5f));
        initWorld();
    }
    RolloverInfo[] javaRollovers = new RolloverInfo[]{
        new RolloverInfo("J"), new RolloverInfo("A"), new RolloverInfo("V"), new RolloverInfo("A")
    };

    public void shoot(boolean shoot) {
        joint.enableMotor(shoot);
    }

    public void rightButtonDown(boolean down) {
        rightFlipperBody.applyTorque(-20f * (down ? 1 : -1));
        rightSmallFlipperBody.applyTorque(-12f * (down ? 1 : -1));
    }

    public void leftButtonDown(boolean down) {
        leftFlipperBody.applyTorque(20f * (down ? 1 : -1));
        leftSmallFlipperBody.applyTorque(12f * (down ? 1 : -1));
    }

    private void initWorld() {
        this.setContactListener(this);
        // flipperBox
        new ChainShapeBuilder(this).position(0, 0).type(BodyType.STATIC).
                chain(
                0f, 0.0f, 0f, 2.4f, 0.2f, 2.6f, 0.05f, 2.9f, 0.14f, 2.97f, 0.38f, 2.8f,
                0.45f, 2.86f, 0.3f, 3.05f, 0.2f, 3.2f, 0.1f, 3.4f, 0f, 3.8f, 0f, 5f, 0.1f, 5.3f,
                0.2f, 5.4f, 0.3f, 5.5f, 0.5f, 5.6f, 0.8f, 5.7f, 1.6f, 5.85f, 2.5f, 5.7f,
                2.84f, 5.6f, 3.1f, 5.4f, 3.2f, 5.3f, 3.3f, 5.2f, 3.3f, -.6f).
                restitution(.08f).build();
        // --------launcher wall--------
        // left lower part
        new ChainShapeBuilder(this).position(0, 0).type(BodyType.STATIC).
                chain(
                3f, 2.4f, 2.8f, 2.6f, 3, 2.9f, 3, 3.2f, 2.7f, 2.8f, 2, 3.4f, 2, 3.9f).
                restitution(.9f).build();
        new ChainShapeBuilder(this).position(0, 0).type(BodyType.STATIC).chain(
                3f, 1.1f, 3, 5f, 3.1f, 5f, 3.1f, 1.1f, 3f, 1.1f).
                restitution(.08f).userData("launcher").build();
        // left upper part

        // Slingshots
        new ChainShapeBuilder(this).position(0, 0).type(BodyType.STATIC).loop(
                0.4f, 1.2f, 0.7f, 1f, 0.4f, 1.7f).userData("slingshot").
                restitution(1.2f).build();
        new ChainShapeBuilder(this).position(0, 0).type(BodyType.STATIC).loop(
                2.3f, 1f, 2.6f, 1.2f, 2.6f, 1.7f).userData("slingshot").
                restitution(1.2f).build();
        // flipper ramps
        new ChainShapeBuilder(this).position(0, 0).type(BodyType.STATIC).chain(
                0.2f, 1.8f, 0.2f, 1f, 0.8f, .7f).restitution(.08f).build();
        new ChainShapeBuilder(this).position(0, 0).type(BodyType.STATIC).
                chain(2.2f, 0.7f, 2.8f, 1f, 2.8f, 1.8f).restitution(.08f).
                build();

        // lanes
        new ChainShapeBuilder(this).position(0.7f, 5.1f).type(BodyType.STATIC).
                loop(
                laneShape).restitution(.95f).userData("lane").build();

        new ChainShapeBuilder(this).position(.9f, 5.1f).type(BodyType.STATIC).
                loop(
                rolloverShape).sensor(true).userData(javaRollovers[0]).build();
        new ChainShapeBuilder(this).position(1f, 5.1f).type(BodyType.STATIC).
                loop(
                laneShape).restitution(.95f).userData("lane").build();
        new ChainShapeBuilder(this).position(1.2f, 5.1f).type(BodyType.STATIC).
                loop(
                rolloverShape).sensor(true).userData(javaRollovers[1]).build();
        new ChainShapeBuilder(this).position(1.3f, 5.1f).type(BodyType.STATIC).
                loop(
                laneShape).restitution(.95f).userData("lane").build();
        new ChainShapeBuilder(this).position(1.5f, 5.1f).type(BodyType.STATIC).
                loop(
                rolloverShape).sensor(true).userData(javaRollovers[2]).build();
        new ChainShapeBuilder(this).position(1.6f, 5.1f).type(BodyType.STATIC).
                loop(
                laneShape).restitution(.95f).userData("lane").build();
        new ChainShapeBuilder(this).position(1.8f, 5.1f).type(BodyType.STATIC).
                loop(
                rolloverShape).sensor(true).userData(javaRollovers[3]).build();
        new ChainShapeBuilder(this).position(1.9f, 5.1f).type(BodyType.STATIC).
                loop(
                laneShape).restitution(.95f).userData("lane").build();

        // left side small field
        new ChainShapeBuilder(this).position(2f, 3.8f).type(BodyType.STATIC).
                chain(.1f, 0, 0, .05f, 0f, 1.15f, 0.1f, 1.3f, 0.2f, 1.36f, 0.3f, 1.39f, 0.5f, 1.4f,
                0.7f, 1.39f, 0.8f, 1.36f, 0.9f, 1.3f, 1f, 1.15f, 1f, 0.05f, .9f, 0).
                restitution(.5f).userData("border").build();
        // loop
        new ChainShapeBuilder(this).position(2f, 3.8f).type(BodyType.STATIC).
                loop(0.2f, .75f, 0.25f, 1.16f, 0.3f, 1.19f, 0.5f, 1.2f,
                0.6f, 1.19f, 0.8f, 1.1f, .8f, .75f, .7f, .75f, .65f, .85f,
                .6f, 1.1f, .44f, 1.1f,
                0.4f, .85f, .3f, .75f).restitution(.5f).userData("duke").build();
        new ChainShapeBuilder(this).position(2.01f, 3.41f).type(BodyType.STATIC).
                chain(0, 0, .98f, 0).sensor(true).userData("smallFieldExit").
                build();

        new ChainShapeBuilder(this).position(2.42f, 4.1f).type(BodyType.STATIC).
                loop(0f, 0f, .051f, .05f, 0.1f, 0f).restitution(.5f).build();

        leftSmallFlipperBody = createFlipper(new Vec2(2.25f, 3.73f), .3f, 0.1f, true);
        rightSmallFlipperBody = createFlipper(new Vec2(2.75f, 3.73f), .3f, 0.1f, false);
        // sensors
        // left trap
        new CircleShapeBuilder(this).radius(0.07f).position(leftTrapPosition).
                type(BodyType.STATIC).sensor(true).gravityScale(1.0f).
                userData("lefttrap").build();
        // left roundabout ramp
        new CircleShapeBuilder(this).radius(0.07f).position(0.2f, 3.4f).
                type(BodyType.STATIC).sensor(true).userData("rollover").build();
        // right trap
        new CircleShapeBuilder(this).radius(0.07f).position(rightTrapPosition).
                type(BodyType.STATIC).sensor(true).userData("rollover").build();
        // left save tunnel
        new ChainShapeBuilder(this).position(0.1f, 1.5f).type(BodyType.STATIC).
                loop(
                longrolloverShape).sensor(true).userData(new RolloverInfo("F")).
                build();
        // left lost tunnel
        new ChainShapeBuilder(this).position(0.3f, 1.5f).type(BodyType.STATIC).
                loop(
                longrolloverShape).sensor(true).userData(new RolloverInfo("X")).
                build();
        // right lost tunnel
        new ChainShapeBuilder(this).position(2.9f, 1.5f).type(BodyType.STATIC).
                loop(
                longrolloverShape).sensor(true).userData(new RolloverInfo("E")).
                build();
        // right save tunnel
        new ChainShapeBuilder(this).position(2.7f, 1.5f).type(BodyType.STATIC).
                loop(
                longrolloverShape).sensor(true).userData(new RolloverInfo("E")).
                build();
        // inside duke
        new CircleShapeBuilder(this).radius(0.07f).position(insideDuke).
                type(BodyType.STATIC).sensor(true).userData("insideDuke").
                build();

        // bottom ramp
        new ChainShapeBuilder(this).position(0, 0).
                chain(0.0f, 0.3f, 3.1f, -0.2f, 3.1f, -.6f).type(BodyType.STATIC).
                build();
        // Bumper
        new CircleShapeBuilder(this).userData("bumper").type(BodyType.STATIC).radius(.2f).
                position(0.9f, 4.6f).restitution(1.2f).density(2).
                friction(0).build();
        new CircleShapeBuilder(this).userData("bumper").type(BodyType.STATIC).
                position(1.275f, 4.1f).restitution(1.2f).radius(.2f).density(2).
                friction(0).build();
        new CircleShapeBuilder(this).userData("bumper").type(BodyType.STATIC).
                position(1.65f, 4.6f).restitution(1.2f).radius(.2f).density(2).
                friction(0).build();
        //doors
//        new ChainShapeBuilder(this).position(3.0f, 5f).restitution(.7f).chain(0, 0, .3f, 0.1f).
//                userData(new Door(false, false)).
//                type(BodyType.STATIC).build();

        new ChainShapeBuilder(this).position(.75f, 5.4f).restitution(.7f).
                chain(0, 0, -.1f, 0.4f).userData(new Door(true, true)).
                type(BodyType.STATIC).build();
        new ChainShapeBuilder(this).position(1.95f, 5.4f).restitution(.7f).
                chain(0, 0, .1f, 0.4f).userData(new Door(true, false)).
                type(BodyType.STATIC).build();


        leftFlipperBody = createFlipper(new Vec2(1.04f, .58f), .55f, 0.14f, true);
        rightFlipperBody = createFlipper(new Vec2(1.96f, .58f), .55f, 0.14f, false);
        joint = createPlunger();
    }
    int delay = 60;
    int counter = 0;
    private Body dummy;

    @Override
    public void step(float dt, int velocityIterations, int positionIterations) {

        super.step(dt, velocityIterations, positionIterations);
        if (dead != null) {
            destroyBody(dead);
            dead = null;
            counter = 1;
        }
        if (counter > 0) {
            counter++;
        }
        if (counter > delay) {
            addBall(dropPoint);
            counter = 0;
        }

    }

    public void addBall() {

        addBall(new Vec2(2.5f, 4.7f));
    }

    public Body addBall(Vec2 position) {
        return new CircleShapeBuilder(this).type(BodyType.DYNAMIC).bullet(true).
                position(position).userData("ball").radius(ball_radius).
                density(2).friction(0).build();
    }

    private PrismaticJoint createPlunger() {
        // Create a body definition
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyType.DYNAMIC;
        bodyDef.position = new Vec2(3.2f, -.5f);
        bodyDef.userData = "plunger";
        PolygonShape shape = new PolygonShape();
        shape.setAsBox(.05f, .2f);

        // Define the dynamic body fixture.
        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1.0f;
        fixtureDef.friction = 0.99f;
        fixtureDef.restitution = 0.01f;

        Body body = createBody(bodyDef);
        body.createFixture(fixtureDef);

        // create an invisible static body to attach joint to
        BodyDef invisibleBodyDef = new BodyDef();
        bodyDef.position = body.getWorldCenter();
        Body staticBody = createBody(invisibleBodyDef);
        staticBody.createFixture(fixtureDef);
        // Create a prismatic joint to make plunger go up/down
        PrismaticJointDef jointDef = new PrismaticJointDef();
        Vec2 worldAxis = new Vec2(0.0f, 1f);
        jointDef.initialize(staticBody, body, body.getWorldCenter(), worldAxis);
        jointDef.lowerTranslation = -0.2f;
        jointDef.upperTranslation = 0.075f;
        jointDef.enableLimit = true;
        jointDef.maxMotorForce = 200.0f;
        jointDef.motorSpeed = 20.0f;
        jointDef.enableMotor = true;
        PrismaticJoint createJoint = (PrismaticJoint) createJoint(jointDef);
        return createJoint;
    }

    private Body createFlipper(Vec2 position, float length, float height, boolean left) {
        FlipperInfo info = new FlipperInfo();
        info.setLength(length);
        info.setLeft(left);
        info.setHeight(height);
        float halfLength = (length / 2);
        float halfHeight = height / 2;
        float centerX = -halfLength + halfHeight;
        float centerY = 0f;
        info.setPivotX(centerX);
        info.setPivotY(centerY);
        float curveX = (float) (Math.cos(0.7853982) * halfHeight);
        float curveY = (float) (Math.sin(0.7853982) * halfHeight);
        Body flipperBody = null;
        if (left) {
            flipperBody = new PolygonShapeBuilder(this).position(position).
                    type(BodyType.DYNAMIC).vertices(-halfLength, 0.0f,
                    centerX - curveX, centerY + curveY,
                    centerX, halfHeight,
                    halfLength - (halfHeight / 2), halfHeight / 2,
                    halfLength, 0,
                    halfLength - (halfHeight / 2), -halfHeight / 2,
                    centerX - curveX, centerY - curveY,
                    centerX, -halfHeight).userData(info).density(1).friction(0).
                    restitution(.5f).build();
        } else {
            centerX = halfLength - halfHeight;

            flipperBody = new PolygonShapeBuilder(this).position(position).
                    type(BodyType.DYNAMIC).vertices(halfLength, 0.0f,
                    centerX + curveX, centerY + curveY,
                    centerX, halfHeight,
                    -halfLength + (halfHeight / 2), halfHeight / 2,
                    -halfLength, 0,
                    -halfLength + (halfHeight / 2), -halfHeight / 2,
                    centerX, -halfHeight,
                    centerX + curveX, centerY - curveY).userData(info).
                    density(1).friction(0).restitution(.5f).build();
        }

//        Body flipperBody = new BoxBuilder(this).type(BodyType.DYNAMIC).position(position).
//                halfWidth(length / 2).halfHeight(height / 2).density(2).friction(0).
//                userData(info).restitution(.5f).
//                build();
        Vec2 jointPosition = position.add(new Vec2(((length / 2) - halfHeight) * (left ? -1 : 1), 0));
        info.setJointPosition(jointPosition);
        Body circleBody = new CircleShapeBuilder(this).type(BodyType.STATIC).
                position(jointPosition).build();

        RevoluteJointDef revoluteJointDef = new RevoluteJointDef();
        revoluteJointDef.initialize(flipperBody, circleBody, jointPosition);
        revoluteJointDef.upperAngle = left ? .3f : .6f;
        revoluteJointDef.lowerAngle = left ? -.6f : -.3f;
        revoluteJointDef.enableLimit = true;
        revoluteJointDef.maxMotorTorque = 10.0f;
        revoluteJointDef.motorSpeed = 0.0f;
        revoluteJointDef.enableMotor = true;
        this.createJoint(revoluteJointDef);
        return flipperBody;
    }

    public final int getScore() {
        return score.get();
    }

    public final void setScore(int value) {
        score.set(value);
    }

    public IntegerProperty scoreProperty() {
        return score;
    }

    public void loopJavaRollovers() {
        boolean lit = javaRollovers[3].isLit();
        for (RolloverInfo info : javaRollovers) {
            boolean current = info.isLit();
            info.setLit(lit);
            lit = current;
        }
    }

    @Override
    public void beginContact(Contact contact) {
        if ("lefttrap".equals(contact.getFixtureA().getBody().getUserData())) {
            setScore(getScore() + 100);
            dead = contact.getFixtureB().getBody();
            dropPoint = insideDuke;
        }
        if ("smallFieldExit".equals(contact.getFixtureA().getBody().
                getUserData())) {
            setScore(getScore() + 100);
            dead = contact.getFixtureB().getBody();
            dropPoint = rightTrapPosition;
        }
        if ("insideDuke".equals(contact.getFixtureA().getBody().getUserData())) {
            setScore(getScore() + 100);
            if (dukeNoseLighter != null) {
                dukeNoseLighter.lightUp(true);
            }
        }
    }

    @Override
    public void endContact(Contact contact) {
        if ("bumper".equals(
                contact.getFixtureA().getBody().getUserData())) {
            setScore(getScore() + 100);
        } else if (contact.getFixtureA().getBody().getUserData() instanceof RolloverInfo) {
            RolloverInfo info = (RolloverInfo) contact.getFixtureA().getBody().
                    getUserData();
            if (info.isLit()) {
                setScore(getScore() + info.getValue());
            }
            info.setLit(false);
            checkRollovers();
        }
        if ("insideDuke".equals(contact.getFixtureA().getBody().getUserData())) {
            if (dukeNoseLighter != null) {
                dukeNoseLighter.lightUp(false);
            }
        }
    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold) {
        Door door = null;
        float a_y = 0, b_y = 0, a_x = 0, b_x = 0;
        if (contact.getFixtureA().getBody().getUserData() instanceof Door) {
            door = (Door) contact.getFixtureA().getBody().getUserData();
            a_y = contact.getFixtureA().getBody().getPosition().y;
            b_y = contact.getFixtureB().getBody().getPosition().y - ball_radius;
            a_x = contact.getFixtureA().getBody().getPosition().x;
            b_x = contact.getFixtureB().getBody().getPosition().x - ball_radius;
        } else if (contact.getFixtureB().getBody().getUserData() instanceof Door) {

            door = (Door) contact.getFixtureB().getBody().getUserData();
            a_y = contact.getFixtureB().getBody().getPosition().y;
            b_y = contact.getFixtureA().getBody().getPosition().y - ball_radius;
            a_x = contact.getFixtureB().getBody().getPosition().x;
            b_x = contact.getFixtureA().getBody().getPosition().x - ball_radius;
        }
        if (door != null) {
            if (!door.isX_axis()) {

                if (door.isClockwise()) {
                    if (b_y > a_y) {
                        contact.setEnabled(false);
                    } else {
                        contact.setEnabled(true);
                    }
                } else {
                    if (b_y < a_y) {
                        contact.setEnabled(false);
                    } else {
                        contact.setEnabled(true);
                    }
                }
            } else {
                if (door.isClockwise()) {
                    if (b_x + (2 * ball_radius) < a_x) {
                        contact.setEnabled(false);
                    } else {
                        contact.setEnabled(true);
                    }
                } else {
                    if (b_x > a_x) {
                        contact.setEnabled(false);
                    } else {
                        contact.setEnabled(true);
                    }
                }
            }
        }
    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {
    }

    private void checkRollovers() {
        boolean someLeft = false;
        for (RolloverInfo info : javaRollovers) {
            if (info.isLit()) {
                someLeft = true;
            }
        }
        if (!someLeft) {

            javaSolvedProperty.add(1);
            score.setValue(score.getValue() + (JAVA_POINTS * javaSolvedProperty.
                    getValue()));
            for (RolloverInfo info : javaRollovers) {
                info.setLit(true);
            }
        }
    }
}
